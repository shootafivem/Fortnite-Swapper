﻿namespace CUE4Parse.UE4.Assets.Exports.Sound
{
    public abstract class USoundBase : UObject { }
}