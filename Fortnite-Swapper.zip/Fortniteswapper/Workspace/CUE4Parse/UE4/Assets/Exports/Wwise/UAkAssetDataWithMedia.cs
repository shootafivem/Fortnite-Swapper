namespace CUE4Parse.UE4.Assets.Exports.Wwise
{
    public class UAkAssetDataWithMedia : UAkAssetData { }
}
