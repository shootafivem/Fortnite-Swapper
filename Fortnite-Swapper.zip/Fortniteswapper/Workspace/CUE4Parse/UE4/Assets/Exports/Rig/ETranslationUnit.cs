﻿namespace CUE4Parse.UE4.Assets.Exports.Rig
{
    public enum ETranslationUnit : byte
    {
        CM,
        M
    }
}
