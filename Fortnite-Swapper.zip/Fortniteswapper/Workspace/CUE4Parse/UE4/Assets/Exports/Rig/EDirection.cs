﻿namespace CUE4Parse.UE4.Assets.Exports.Rig
{
    public enum EDirection : byte
    {
        Left,
        Right,
        Up,
        Down,
        Front,
        Back
    }
}
