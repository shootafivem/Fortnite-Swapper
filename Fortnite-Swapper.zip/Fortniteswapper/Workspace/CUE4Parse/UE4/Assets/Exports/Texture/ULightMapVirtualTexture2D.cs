namespace CUE4Parse.UE4.Assets.Exports.Texture;

public class ULightMapVirtualTexture2D : UTexture2D { }
