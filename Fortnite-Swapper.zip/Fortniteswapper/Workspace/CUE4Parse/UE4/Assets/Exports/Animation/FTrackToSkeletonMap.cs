﻿namespace CUE4Parse.UE4.Assets.Exports.Animation
{
    public struct FTrackToSkeletonMap
    {
        public int BoneTreeIndex;
    }
}