﻿namespace CUE4Parse.UE4.Assets.Exports.Animation.ACL
{
    public class UAnimBoneCompressionCodec_ACLSafe : UAnimBoneCompressionCodec_ACLBase { }
}