namespace CUE4Parse.UE4.Assets.Exports.Component
{
    public class USceneComponent : UObject
    {
    }
}
