namespace CUE4Parse.UE4.Assets.Exports.Component.StaticMesh
{
    public class UAsyncStaticMeshComponent : UStaticMeshComponent
    {
    }
}
