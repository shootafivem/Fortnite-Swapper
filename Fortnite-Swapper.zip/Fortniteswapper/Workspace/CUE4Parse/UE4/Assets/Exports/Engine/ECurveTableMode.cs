﻿namespace CUE4Parse.UE4.Assets.Exports.Engine
{
    public enum ECurveTableMode : byte
    {
        Empty,
        SimpleCurves,
        RichCurves
    }
}
