﻿namespace CUE4Parse.UE4.Assets.Exports.Material
{
    public enum ETextureChannel
    {
        TC_NONE,
        TC_R,
        TC_G,
        TC_B,
        TC_A,
        TC_MA
    }
}