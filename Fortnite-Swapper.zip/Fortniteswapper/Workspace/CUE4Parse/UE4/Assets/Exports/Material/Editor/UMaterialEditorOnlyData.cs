namespace CUE4Parse.UE4.Assets.Exports.Material.Editor;

public class UMaterialEditorOnlyData : UMaterialInterfaceEditorOnlyData { }