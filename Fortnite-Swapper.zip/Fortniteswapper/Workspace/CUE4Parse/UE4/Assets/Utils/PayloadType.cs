﻿namespace CUE4Parse.UE4.Assets.Utils
{
    public enum PayloadType
    {
        UBULK,
        UPTNL
    }
}