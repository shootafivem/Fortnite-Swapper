﻿namespace CUE4Parse.UE4.AssetRegistry.Objects
{
    public enum ELoadOrder
    {
        Member,
        TextFirst
    }
}