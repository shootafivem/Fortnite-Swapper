using CUE4Parse.UE4.Assets.Exports.Component.StaticMesh;
using CUE4Parse.UE4.Assets.Exports.Texture;

namespace CUE4Parse.GameTypes.SWJS.Assets.Exports;

public class URsColorGradeTexture : UTexture2D { }
public class URsWorldMapStaticMeshComponent : UStaticMeshComponent { }
public class URsWorldMapInstancedStaticMeshComponent : UInstancedStaticMeshComponent { }
