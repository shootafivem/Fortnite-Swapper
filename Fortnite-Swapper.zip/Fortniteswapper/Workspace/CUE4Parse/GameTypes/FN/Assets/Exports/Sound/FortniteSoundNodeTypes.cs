using CUE4Parse.UE4.Assets.Exports.Sound.Node;

namespace CUE4Parse.GameTypes.FN.Assets.Exports.Sound
{
    public class UFortSoundNodeLicensedContentSwitcher : USoundNode { }
}
