using CUE4Parse.UE4.Objects.MediaAssets;

namespace CUE4Parse.GameTypes.FN.Objects.MediaAssets
{
    public class UFortStreamMediaSource : UBaseMediaSource { }
}
