﻿using CUE4Parse.UE4.Assets.Exports.Sound;

namespace CUE4Parse.GameTypes.ST2.UE4.Assets.Exports.Sound;

public class VoiceGenSoundWave : USoundWave { }
