﻿namespace CUE4Parse.UE4.Objects.MediaAssets
{
    public class UStreamMediaSource : UBaseMediaSource { }
}
