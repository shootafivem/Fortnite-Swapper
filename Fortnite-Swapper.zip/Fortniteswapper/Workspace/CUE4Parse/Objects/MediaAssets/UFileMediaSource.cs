namespace CUE4Parse.UE4.Objects.MediaAssets
{
    public class UFileMediaSource : UBaseMediaSource { }
}
