﻿namespace CUE4Parse.UE4.Objects.UObject
{
    public interface IObject
    {
        
    }
}
