## Fortnite Swapper

Make Fortnite look better and get all the skins to troll and ect!

Steps 

It's reccomended to turn anti-virus off as this could mess up the program while it's trying to run. 

#######FULL VIDEO WILL BE POSTED SOON#######


(1) ~ Turn Anti-Virus off (or keep it on and see if it works) 

(2) ~ Close Epic Games and Discord 

(3) ~ Open the swapper.exe

(4) ~ Open epic games 

(5) ~ Open Discord 

(6) ~ Open Fortnite

(7) ~ Share with your friends ~ 


If there is a problem please message my discord! 

sgote3 

Alt is used to avoid being banned!